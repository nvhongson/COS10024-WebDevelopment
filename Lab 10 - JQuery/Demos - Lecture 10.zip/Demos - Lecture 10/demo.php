<html> 
<head>
	<meta charset="utf-8"  />
	<title>Sample Embedded CSS</title>
	<script src="jquery-1.9.1.min.js"></script>
	<script type="text/javascript" src="demo.js"></script>
</head>
<body> 
<h1>Hello World!</h1>
<?php
	$username = $_POST["username"];
	$number = rand(1,10);
	echo "<p>";
	echo "<h1>".$username.", you have ".$number." new emails.</h1>";
	$i=1;
	while($i<=$number) { 
		echo "<p><h2>Email #".$i."</h2></p>"; 
		$i++; 
	}
	echo "</p>"; 
?> 
</body> 
</html> 
