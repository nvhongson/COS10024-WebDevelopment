function showAgeTip() {
  $(this).after("<span class=\"tooltip\">	must be above 18yo</span>");
}

function hideAgeTip() {
  $(this).next().remove();
}



function execute() {
	
	$("#imgSmiley").animate({height:"300px"});
	
}

function zoomout() {
	$("#imgSmiley").animate({height:"100px"});	
}

function init() {
	
	$imgSmiley = $("#imgSmiley");
	$imgSmiley.mouseover(execute);
	$imgSmiley.mouseout(zoomout);
	
	 $("#tbAge").focusin(showAgeTip);
	$("#tbAge").focusout(hideAgeTip);

}

$(document).ready(init);