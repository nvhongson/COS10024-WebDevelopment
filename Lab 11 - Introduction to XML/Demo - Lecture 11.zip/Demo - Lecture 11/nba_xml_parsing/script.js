//function execute() will execute function parseXML() only when the form validation succeeded

function parseXML() {
	var xhttp = new XMLHttpRequest();		//Create a XML HTTP request object
	
	xhttp.open("GET", "nba.xml", false);	//setup the XML HTTP request
	xhttp.send();							//send the requrest to retrieve the XML document
	
	var xmlDoc=xhttp.responseXML;				//obtain received XML document
	
	var Teams = xmlDoc.getElementsByTagName("Team");
	var TeamNames = xmlDoc.getElementsByTagName("TeamName");
	var StarPlayers = xmlDoc.getElementsByTagName("StarPlayer");
	var Locations = xmlDoc.getElementsByTagName("Location");
	var Stadiums = xmlDoc.getElementsByTagName("Stadium");
	
	var divResult = document.getElementById("divResult");
	divResult.innerHTML += "<h1>NBA Teams</h1>";
	
	for(var i=0; i<Teams.length; ++i) {
		divResult.innerHTML += "<h2>"+ (i+1) + ". " + TeamNames[i].childNodes[0].nodeValue+"</h2>";
		
		divResult.innerHTML += "Location: ";
		divResult.innerHTML += Locations[i].childNodes[0].nodeValue;
		divResult.innerHTML += "<br />";
		
		divResult.innerHTML += "Star Player: ";
		divResult.innerHTML += StarPlayers[i].childNodes[0].nodeValue;
		divResult.innerHTML += "<br />";
		
		divResult.innerHTML += "Stadium: ";
		divResult.innerHTML += Stadiums[i].childNodes[0].nodeValue;
		divResult.innerHTML += "<br />";
	}
	return false;
}

//link functions to elements' events
function init() {
	$("#btnExecute").click(parseXML);
	$("#xmlForm").submit(parseXML);
}

//the initialise function
$(document).ready(init);