
//old approach
function parseXML(){
    var xmlhttp;
    if(window.XMLHttpRequest){
            // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }else{
            // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    
    xmlhttp.open("GET", "./teams.xml", false); 
    xmlhttp.send();
    
    var xmlDoc = xmlhttp.responseXML; 
    var Teams = xmlDoc.getElementsByTagName("Team");
    var TeamNames = xmlDoc.getElementsByTagName("TeamName");
    var StarPlayers = xmlDoc.getElementsByTagName("StarPlayer");
    var Locations = xmlDoc.getElementsByTagName("Location");
    var Stadiums = xmlDoc.getElementsByTagName("Stadium");
    
    for(var i=0; i<Teams.length; ++i) {
        document.write("<h2>");
        document.write(i+"."+TeamNames[i].childNodes[0].nodeValue);
        document.write("</h2>");
        document.write("Location: ");
        document.write(Locations[i].childNodes[0].nodeValue);
        document.write("<br />");
        document.write("Star Player: ");
        document.write(StarPlayers[i].childNodes[0].nodeValue);
        document.write("<br />");
        document.write("Stadium: ");
        document.write(Stadiums[i].childNodes[0].nodeValue);
        document.write("<br />");
    }
}
function init() {
    $("#btnExecute").click(parseXML);
}
$(document).ready(init);



//New approach
var openFile = function(event) {
	var input = event.target;
    var text = "";
	var reader = new FileReader();
	var onload = function(event) {
		text = reader.result;
		parseFile(text);

	};
	reader.onload = onload;
    reader.readAsText(input.files[0]);

};

var parseFile = function(text) {
	var xmlDoc = $.parseXML(text); //$xml = $(xmlDoc), $options = $xml.find("team");

       
        var Teams = xmlDoc.getElementsByTagName("Team");
        var TeamNames = xmlDoc.getElementsByTagName("TeamName");
        var StarPlayers = xmlDoc.getElementsByTagName("StarPlayer");
        var Locations = xmlDoc.getElementsByTagName("Location");
        var Stadiums = xmlDoc.getElementsByTagName("Stadium");
    
        for(var i=0; i<Teams.length; i++) {
            document.write("<h2>");
            document.write(i+1+"."+TeamNames[i].childNodes[0].nodeValue);
            document.write("</h2>");
            document.write("Location: ");
            document.write(Locations[i].childNodes[0].nodeValue);
            document.write("<br />");
            document.write("Star Player: ");
            document.write(StarPlayers[i].childNodes[0].nodeValue);
            document.write("<br />");
            document.write("Stadium: ");
            document.write(Stadiums[i].childNodes[0].nodeValue);
            document.write("<br />");
        }  
        


};
