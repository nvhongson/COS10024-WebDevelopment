


$(document).ready(init);


function init() {
    
    $("#fileSelect").change(pickupFile); 
}



function pickupFile(){
    var file =this.files[0]; 
    
    var reader = new FileReader(); 
    //The FileReader.onload property contains an event handler executed when the load event is fired, when content read with readAsArrayBuffer, readAsBinaryString, readAsDataURL or readAsText is available
    reader.onload = readOnload; 
    reader.readAsText(file);
    
}


//after a file has been read, it will be parsed here
function readOnload(){ 
    var text = this.result;
    parseFile(text);
}


//process the xml file
function parseFile(text){
    var parser = new DOMParser();
    xmlDoc = parser.parseFromString(text,"text/xml");
    
    var Teams = xmlDoc.getElementsByTagName("Team");
        var TeamNames = xmlDoc.getElementsByTagName("TeamName");
        var StarPlayers = xmlDoc.getElementsByTagName("StarPlayer");
        var Locations = xmlDoc.getElementsByTagName("Location");
        var Stadiums = xmlDoc.getElementsByTagName("Stadium");
        var htmlstr = "";
        for(var i=0; i<Teams.length; ++i) {
            htmlstr+="<h2>";
            htmlstr+=i+1+"."+TeamNames[i].childNodes[0].nodeValue;
            htmlstr+="</h2>";
            htmlstr+="Location: ";
            htmlstr+=Locations[i].childNodes[0].nodeValue;
            htmlstr+="<br />";
            htmlstr+="Star Player: ";
            htmlstr+=StarPlayers[i].childNodes[0].nodeValue;
            htmlstr+="<br />";
            htmlstr+="Stadium: ";
            htmlstr+=Stadiums[i].childNodes[0].nodeValue;
            htmlstr+="<br />";
        } 
    $("#result").html(htmlstr);
}
