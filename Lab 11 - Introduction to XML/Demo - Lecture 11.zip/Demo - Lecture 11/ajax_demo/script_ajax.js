function parseXML() {

	var xmlhttp = new XMLHttpRequest();		//Create a XML HTTP request object

	xmlhttp.onreadystatechange=function () {
		
		if((xmlhttp.readyState == 4) && (xmlhttp.status == 200)) {  //when the xml data is ready
			var xmlData=xmlhttp.responseText;		//obtain received XML document
			document.getElementById("pResult").innerHTML += xmlData;
			document.getElementById("pResult").innerHTML += "<br />";
		}
	}
	
	xmlhttp.open("GET", "xml.php", true);	//setup the XML HTTP request

	xmlhttp.send();							//send the requrest to retrieve the XML document
}

//link functions to elements' events
function init() {
	$("#btnExecute").click(parseXML);
	$("#xmlForm").submit(parseXML);
}

//the initialise function
$(document).ready(init);